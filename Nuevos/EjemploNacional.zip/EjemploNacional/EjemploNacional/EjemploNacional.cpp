/*
Encontrar tres n�meros enteros positivos X, Y, Z tales que entre el mayor y el menor de 
ellos la diferencia no es mayor que 5 y adem�s X�2159 + Y�1779 + Z�1149 = 218630.

SOLUCI�N: X=43  -  Y=41  -  Z=46
*/

#include <iostream>
using namespace std;

int main()
{
	int mayor=0;
	int menor=0;
	int diferencia=0;
	bool solucion=false;

	while(solucion==false)
	{
		for(int x=0; x<=102; x++)
		{
			for(int y=0; y<=123; y++)
			{
				for(int z=0; z<=191; z++)
				{
					int cuenta=x*2159+y*1779+z*1149;
					if(cuenta==218630)
					{
						if(x<y&&x<z)
						{
							menor=x;
						}
						else if(y<z&&y<x)
						{
							menor=y;
						}
						else
						{
							menor=z;
						}
						if(x>y&&x>z)
						{
							mayor=x;
						}
						else if(y>x&&y>z)
						{
							mayor=y;
						}
						else
						{
							mayor=z;
						}

						diferencia=mayor-menor;
						if(diferencia<=5)
						{
							solucion=true;
							cout << "Solucion: " << "X= " << x << "	Y= "<< y <<"	Z="	<< z << "." << endl; 
							break;
						}
					}
				}
			}
		}
	}
	system("pause");
	return 0;
}